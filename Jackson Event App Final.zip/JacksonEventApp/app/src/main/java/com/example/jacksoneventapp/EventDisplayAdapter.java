package com.example.jacksoneventapp;

import android.annotation.SuppressLint;
import android.hardware.camera2.CaptureRequest;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class EventDisplayAdapter extends RecyclerView.Adapter<EventDisplayAdapter.EventViewHolder> {



    // Initialize the eventList
    List<Event> eventList = new ArrayList<>();

    private OnDeleteClickListener onDeleteClickListener; // Declare the listener variable


    private Button deleteButton;

    public void setOnDeleteClickListener(OnDeleteClickListener listener) {
        onDeleteClickListener = listener;
    }

    public EventDisplayAdapter(List<Event> eventList) {
    }

    public void setEventList(List<Event> eventList) {
        this.eventList = eventList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.display_data, parent, false);  // Use the correct layout here
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Event event = eventList.get(position);
        holder.bindEvent(event);
        holder.setOnDeleteClickListener(onDeleteClickListener); // Set the listener here
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onDeleteClickListener != null) {
                    onDeleteClickListener.onDeleteClick(position); // Call the interface method
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    public void setOnDeleteClickListener(eventDisplayActivity eventDisplayActivity) {
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    class EventViewHolder extends RecyclerView.ViewHolder {

        public Button deleteButton;
        private TextView eventTitleTextView;
        private TextView eventDateTextView;
        private TextView eventTimeTextView;
        private OnDeleteClickListener onDeleteClickListener;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventTitleTextView = itemView.findViewById(R.id.event_title);
            eventDateTextView = itemView.findViewById(R.id.event_date);
            eventTimeTextView = itemView.findViewById(R.id.event_time);
            deleteButton = itemView.findViewById(R.id.deleteButton);

            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onDeleteClickListener != null) {
                        onDeleteClickListener.onDeleteClick(getAdapterPosition()); // Call the interface method
                    }
                }
            });
        }

        public void bindEvent(Event event) {
            Log.d("EventViewHolder", "Binding event: " + event.getTitle());

            if (eventTitleTextView == null) {
                Log.e("EventViewHolder", "eventTitleTextView is null");
                return;
            }

            eventTitleTextView.setText(event.getTitle());

            SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
            String formattedDate = dateFormat.format(event.getDate());
            eventDateTextView.setText(formattedDate);

            eventTimeTextView.setText(event.getTime());

        }


        public void setOnDeleteClickListener(OnDeleteClickListener onDeleteClickListener) {
            this.onDeleteClickListener = onDeleteClickListener;
        }
    }
}
