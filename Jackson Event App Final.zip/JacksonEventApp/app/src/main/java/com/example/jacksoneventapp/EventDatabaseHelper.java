package com.example.jacksoneventapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EventDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "events.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_EVENTS = "events";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_DATE = "date";  // Use DATE data type
    public static final String COLUMN_TIME = "time";  // Use TIME data type

    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_EVENTS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_TITLE + " TEXT, " +
                    COLUMN_DATE + " DATE, " +  // Change to DATE data type
                    COLUMN_TIME + " TIME)";    // Change to TIME data type

    public EventDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void onCreate(SQLiteDatabase database) {
        database.execSQL(TABLE_CREATE);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    public long insertEvent(String title, Date eventDate, String eventTime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_DATE, eventDate.getTime());
        values.put(COLUMN_TIME, eventTime);
        long newRowId = db.insert(TABLE_EVENTS, null, values);
        db.close();
        return newRowId;
    }

    public void removeEvent(long eventId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_EVENTS, COLUMN_ID + " = ?", new String[]{String.valueOf(eventId)});
        db.close();
    }

    public List<Event> getAllEvents() {
        List<Event> eventList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_EVENTS, null, null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") long eventId = cursor.getLong(cursor.getColumnIndex(COLUMN_ID));
                @SuppressLint("Range") String eventTitle = cursor.getString(cursor.getColumnIndex(COLUMN_TITLE));
                @SuppressLint("Range") long eventDateMillis = cursor.getLong(cursor.getColumnIndex(COLUMN_DATE));
                @SuppressLint("Range") String eventTime = cursor.getString(cursor.getColumnIndex(COLUMN_TIME));

                // Convert eventDateMillis to a Date object
                Date eventDate = new Date(eventDateMillis);

                Event event = new Event(eventTitle, eventDate, eventTime);
                event.setId(eventId); // Set the ID for the Event object
                eventList.add(event);
            }
            cursor.close();
        }

        db.close();
        return eventList;
    }

}

