package com.example.jacksoneventapp;

import java.util.Date;

public class Event {

    private String title;
    private Date date;
    private String time;

    private long ID;
    // Add more properties as needed

    public Event(String title, Date date, String time) {
        this.title = title;
        this.date = date;
        this.time = time;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setId(long ID) {
        this.ID = ID;
    }

    public long getId() {
        return  ID;
    }
}
