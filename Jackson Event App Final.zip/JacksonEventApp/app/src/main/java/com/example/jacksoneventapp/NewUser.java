package com.example.jacksoneventapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NewUser extends AppCompatActivity {

    private userlogindata dbHelper;
    private EditText usernameInput, passwordInput;
    private Button registerButton, backtomainButton;

    private void startNewMainpage() {
        Intent intent = new Intent(NewUser.this, MainActivity.class);
        startActivity(intent);
    }



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newuseredited);



        dbHelper = new userlogindata(this);
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        registerButton = findViewById(R.id.register_button);
        backtomainButton = findViewById(R.id.backtomain);


        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameInput.getText().toString();
                String password = passwordInput.getText().toString();

                // Insert new user into the database
                dbHelper.insertUser(username, password);

                Toast.makeText(NewUser.this, "User registered successfully!", Toast.LENGTH_SHORT).show();
            }
        });
        backtomainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNewMainpage();
            }
        });

    }
}