package com.example.jacksoneventapp;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class eventDisplayActivity extends AppCompatActivity implements eventDisplayAdapter.OnDeleteClickListener {
    private void startLogin() {
        Intent intent = new Intent(eventDisplayActivity.this, eventDisplayActivity.class);
        startActivity(intent);
    }

    public static class SmsHelper {
        public static void sendSms(Context context, String phoneNumber, String message) {
            // Use SmsManager to send SMS
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            // Handle your SMS logic here, e.g., show a confirmation toast
            Toast.makeText(context, "SMS sent: " + message, Toast.LENGTH_SHORT).show();
        }

        public static void sendSms(DialogInterface.OnClickListener onClickListener, String phoneNumber, String message) {
            // Use SmsManager to send SMS
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            // Handle your SMS logic here, e.g., show a confirmation toast
            Context context = null;
            Toast.makeText(context, "SMS sent: " + message, Toast.LENGTH_SHORT).show();
        }
        
    }

    private RecyclerView recyclerView;
    private EventDisplayAdapter eventDisplayAdapter;
    private List<Event> eventList;

    private  EventDatabaseHelper dbHelper;

    private EditText editDate;

    private Button addButton;


    private void loadEventsFromDatabase() {
        eventList.clear(); // Clear existing data
        EventDatabaseHelper dbHelper = new EventDatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Define the columns you want to retrieve
        String[] projection = {
                EventDatabaseHelper.COLUMN_ID,
                EventDatabaseHelper.COLUMN_TITLE,
                EventDatabaseHelper.COLUMN_DATE,
                EventDatabaseHelper.COLUMN_TIME
        };

        // Query the database
        Cursor cursor = db.query(
                EventDatabaseHelper.TABLE_EVENTS,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        // Iterate through the cursor and populate the eventList
        while (cursor.moveToNext()) {
            long eventId = cursor.getLong(cursor.getColumnIndexOrThrow(EventDatabaseHelper.COLUMN_ID));
            String eventTitle = cursor.getString(cursor.getColumnIndexOrThrow(EventDatabaseHelper.COLUMN_TITLE));
            long eventDateMillis = cursor.getLong(cursor.getColumnIndexOrThrow(EventDatabaseHelper.COLUMN_DATE));
            String eventTime = cursor.getString(cursor.getColumnIndexOrThrow(EventDatabaseHelper.COLUMN_TIME));

            Date eventDate = new Date(eventDateMillis); // Convert millis to Date

            eventList.add(new Event(eventTitle, eventDate, eventTime));
        }

        cursor.close();
        db.close();

        // Notify the adapter that the data has changed
        eventDisplayAdapter.notifyDataSetChanged();
    }



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.eventlistlayout);

        dbHelper = new EventDatabaseHelper(this);

        addButton = findViewById(R.id.add_event);

        // Initialize the RecyclerView and its adapter
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        eventList = new ArrayList<>();  // Populate this list with your events
        eventList.add(new Event("Event 1", new Date(), "10:00 AM"));
        eventList.add(new Event("Event 2", new Date(), "2:00 PM"));

        eventDisplayAdapter = new EventDisplayAdapter(eventList);
        eventDisplayAdapter.setEventList(eventList);
        recyclerView.setAdapter(eventDisplayAdapter);

        loadEventsFromDatabase();



        addButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                // Create a dialog
                AlertDialog.Builder builder = new AlertDialog.Builder(eventDisplayActivity.this);
                View dialogView = getLayoutInflater().inflate(R.layout.display_data, null);
                builder.setView(dialogView);

                // Find the EditText fields in the dialog
                EditText titleEditText = dialogView.findViewById(R.id.event_title);
                EditText dateEditText = dialogView.findViewById(R.id.event_date);
                EditText timeEditText = dialogView.findViewById(R.id.event_time);

                editDate = dialogView.findViewById(R.id.event_date);  // Initialize here

                editDate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        showDatePicker();
                    }
                });


                // Set up the dialog buttons
                builder.setPositiveButton("Create", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Retrieve user input from EditText fields
                        String eventTitle = titleEditText.getText().toString();
                        String eventDateStr = dateEditText.getText().toString();
                        Date eventDate = null;
                        try {
                            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                            eventDate = dateFormat.parse(eventDateStr);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        String eventTime = timeEditText.getText().toString();


                        if (eventTitle.isEmpty() || eventDateStr.isEmpty() || eventTime.isEmpty()) {
                            // Show an error message or toast indicating that fields cannot be empty
                            Toast.makeText(eventDisplayActivity.this, "All fields are required.", Toast.LENGTH_SHORT).show();
                            return;
                        }


                        // Create a new event and add it to the eventList
                        Event newEvent = new Event(eventTitle, eventDate, eventTime);
                        eventList.add(newEvent);

                        //add to database
                        dbHelper.insertEvent(eventTitle,eventDate,eventTime);

                        // Notify the adapter that the data has changed
                        eventDisplayAdapter.notifyDataSetChanged();

                        // Send SMS notification
                        String phoneNumber = "1234567890";
                        String message = "New Event Added:\nTitle: " + eventTitle +
                                "\nDate: " + eventDate +
                                "\nTime: " + eventTime;
                        SmsHelper.sendSms(this, phoneNumber, message);
                    }
                });

                builder.setNegativeButton("Cancel", null);

                // Show the dialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(eventDisplayActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // Month is 0-based, so add 1
                month += 1;
                String selectedDate = year + "-" + month + "-" + day;
                editDate.setText(selectedDate);
            }
        }, year, month, day);

        datePickerDialog.show();
    }
    public void onClickEventDate(View view) {
        showDatePicker();
    }

    private void removeEventFromDatabase(long eventId) {
        EventDatabaseHelper dbHelper = new EventDatabaseHelper(eventDisplayActivity.this);
        dbHelper.removeEvent(eventId);

        // Refresh the RecyclerView by updating the eventList and notifying the adapter
        eventList.clear();
        eventList.addAll(dbHelper.getAllEvents());
        eventDisplayAdapter.notifyDataSetChanged();
    }

    public void deleteEvent(View view) {
        // Get the event ID associated with the clicked button
        Long eventId = (Long) view.getTag();

        if (eventId == null) {

            Toast.makeText(this, "Event ID is null, cannot delete event", Toast.LENGTH_SHORT).show();
            return;
        }

        // Call the removeEventFromDatabase method to remove the event
        removeEventFromDatabase(eventId);

        // Update the RecyclerView data
        eventList.clear();
        eventList.addAll(dbHelper.getAllEvents());
        eventDisplayAdapter.notifyDataSetChanged();
    }


    @Override
    public void onDeleteClick(int position) {
        Event eventToDelete = eventList.get(position);
        long eventId = eventToDelete.getId(); // Get the event ID
        removeEventFromDatabase(eventId); // Delete event from the database

        // Remove event from the list and notify the adapter
        eventList.remove(eventToDelete);
        eventDisplayAdapter.notifyDataSetChanged();
    }
}
