package eventDisplayAdapter;

public interface OnDeleteClickListener {
    void onDeleteClick(int position);
}
